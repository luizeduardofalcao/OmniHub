package com.falcao.omnihub.omnihub_core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmniHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmniHubApplication.class, args);
	}

}
