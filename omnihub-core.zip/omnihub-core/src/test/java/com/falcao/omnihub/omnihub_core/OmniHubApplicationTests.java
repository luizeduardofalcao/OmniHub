package com.falcao.omnihub.omnihub_core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmniHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
